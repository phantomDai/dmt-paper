package com.alibaba.json.bvt.asm;

import junit.framework.TestCase;

public class ClassReaderTest extends TestCase {
    public void test_read() throws Exception {

    }
}
