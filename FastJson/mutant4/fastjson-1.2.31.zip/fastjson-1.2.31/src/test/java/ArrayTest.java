/**
 * Created by wenshao on 13/02/2017.
 */
public class ArrayTest {
    public static void main(String[] args) {
        f(new int[] { 101, 102, 103, 104, 105, 106, 107, 108, 109});
    }

    public static void f(int[] a) {
        System.out.println(a.length);
    }
}
